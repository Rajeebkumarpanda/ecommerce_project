import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addToCart, getAllProducts, removeFromCart } from "../redux/features/productSlice";
import { FaPlus } from "react-icons/fa";
import { FaMinus } from "react-icons/fa";

const HomePage = () => {
  const dispatch = useDispatch();
  const result = useSelector((state) => state.product);
  // console.log(result.data.products);
  useEffect(() => {
    dispatch(getAllProducts());
  }, []);

  const quantityCount = 0
  

  const handleAddToCart = (elem) => {
    dispatch(addToCart(elem));
  };
  const handleRemoveFromCart = (elem) => {
    dispatch(removeFromCart(elem));
  };
  return (
    <>
      <div className="w-full bg-gray-300 px-20 grid grid-cols-3 gap-2 pt-5">
        {result.data.products &&
          result.data.products.map((elem) => (
            <div
              key={elem.id}
              className="relative flex w-96 m-2 flex-col rounded-xl bg-white border-2 text-gray-700 shadow-lg"
            >
              <div className="relative mx-4 mt-2 h-56 overflow-hidden rounded-xl bg-blue-gray-500 bg-clip-border text-white shadow-lg shadow-blue-gray-500/40">
                <img src={elem.thumbnail} alt="img-blur-shadow" layout="fill" />
              </div>
              <div className="p-6">
                <h5 className="mb-2 block font-sans text-xl font-semibold leading-snug tracking-normal text-blue-gray-900 antialiased">
                  {elem.title}
                </h5>
                <p className="block font-sans text-base font-light leading-relaxed text-inherit antialiased">
                  $ {elem.price}
                </p>
              </div>
              <div className="p-6 pt-0 flex gap-4 items-center cursor-pointer">
                {/* <button
                  className="select-none rounded-lg bg-pink-500 py-3 px-6 text-center align-middle font-sans text-xs font-bold uppercase text-white shadow-md shadow-pink-500/20 transition-all hover:shadow-lg hover:shadow-pink-500/40 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none"
                  type="button"
                  data-ripple-light="true"
                  onClick={()=>handleAddToCart(elem)}
                >
                  
                </button> */}
                <FaMinus onClick={()=>handleRemoveFromCart(elem)} />
                <p>
                  {result.cart ?result.cart.map((elm) => elm.id === elem.id && elm.quantity) : 0}
                </p>
                <FaPlus onClick={() => handleAddToCart(elem)} />
              </div>
            </div>
          ))}
      </div>
    </>
  );
};

export default HomePage;
